<?php

class BalakaApi{
    
    public function calculateFare(){
        //Do it somehow
    }
    
    public function processCreditCard($card_info){
        //Process card
    }
    
    public function payFare($fare){
        //Paid
    }
    
    public function processReservation(){
        //
    }

    public function confirmReservation(){
        //API Codes
    }
    
    public function getAvailableSits($trip_type, $leaving_from, $departure_date, $return_date, $passanger_type, $travel_class){
        //
    }
        
}