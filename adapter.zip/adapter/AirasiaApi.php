<?php

class AirAsiaApi{
    
    public function checkAvailability($trip_type, $leaving_from, $departure_date, $return_date, $passanger_type, $travel_class){
        //Do it Some how
    }
    
    public function reserve(){
        //API code
    }
    
    public function getTotalBill(){
        //API Code
    }
    
    public function billPay(){
        //API Code
    }
        
}